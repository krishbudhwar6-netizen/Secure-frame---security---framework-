<?php require 'includes/bootstrap.php'; require_perm('manage_roles');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $pdo = db(); $pdo->beginTransaction();
    $pdo->exec("DELETE FROM perms WHERE role!='admin'");
    $ins = $pdo->prepare('INSERT INTO perms VALUES(?,?)');
    foreach (ROLES as $r) { if ($r === 'admin') continue;
        foreach (array_keys(PERMS) as $p) if (!empty($_POST['perm'][$r][$p])) $ins->execute([$r, $p]); }
    $pdo->commit(); log_action('perm_matrix_update'); flash('ok', 'Permissions saved.');
    header('Location: roles.php'); exit;
}
$have = [];
foreach (db()->query('SELECT role,permission FROM perms') as $r) $have[$r['role']][$r['permission']] = true;
$title = 'Roles'; include 'includes/header.php'; ?>
<h1>Role-based access control</h1>
<p class="muted">Tick the permissions each role should have. The admin role always keeps every permission so you cannot lock yourself out.</p>
<form method="post" class="card"><?= csrf_field() ?><div class="scroll"><table><tr><th>Permission</th><?php foreach (ROLES as $r): ?><th><?= e($r) ?></th><?php endforeach; ?></tr>
<?php foreach (PERMS as $k => $label): ?><tr><td><?= e($label) ?></td>
<?php foreach (ROLES as $r): ?><td class="c"><input type="checkbox" name="perm[<?= e($r) ?>][<?= e($k) ?>]" value="1" <?= !empty($have[$r][$k]) ? 'checked' : '' ?> <?= $r === 'admin' ? 'disabled' : '' ?>></td><?php endforeach; ?></tr>
<?php endforeach; ?></table></div><button>Save permissions</button></form>
<?php include 'includes/footer.php'; ?>
