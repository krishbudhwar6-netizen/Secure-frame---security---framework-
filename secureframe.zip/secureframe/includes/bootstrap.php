<?php
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'");

const DB_FILE = __DIR__ . '/../data/app.sqlite';
const ROLES = ['admin', 'manager', 'employee'];
const PERMS = [
    'view_policies'   => 'View policies',
    'manage_policies' => 'Add / delete policies',
    'take_quiz'       => 'Take awareness quiz',
    'view_audit'      => 'View audit log',
    'manage_users'    => 'Manage users',
    'manage_roles'    => 'Edit role permissions',
];

function db() {
    static $pdo = null;
    if (!$pdo) {
        $new = !file_exists(DB_FILE);
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        if ($new) init_db($pdo);
    }
    return $pdo;
}

function init_db($p) {
    $p->exec("
    CREATE TABLE users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, password TEXT,
        role TEXT DEFAULT 'employee', failed INTEGER DEFAULT 0, locked_until INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE policies(id INTEGER PRIMARY KEY, title TEXT, category TEXT, body TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE acks(user_id INTEGER, policy_id INTEGER, acked_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(user_id, policy_id));
    CREATE TABLE perms(role TEXT, permission TEXT, PRIMARY KEY(role, permission));
    CREATE TABLE questions(id INTEGER PRIMARY KEY, q TEXT, opts TEXT, correct INTEGER, explain TEXT);
    CREATE TABLE quiz_results(id INTEGER PRIMARY KEY, user_id INTEGER, score INTEGER, total INTEGER,
        taken_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT, detail TEXT, ip TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);");

    $u = $p->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)');
    foreach ([['Admin User','admin@demo.com','Admin@123','admin'],
              ['Manager User','manager@demo.com','Manager@123','manager'],
              ['Employee User','employee@demo.com','Employee@123','employee']] as $x)
        $u->execute([$x[0], $x[1], password_hash($x[2], PASSWORD_DEFAULT), $x[3]]);

    $pm = $p->prepare('INSERT INTO perms VALUES(?,?)');
    $map = ['admin' => array_keys(PERMS),
            'manager' => ['view_policies','take_quiz','view_audit'],
            'employee' => ['view_policies','take_quiz']];
    foreach ($map as $r => $list) foreach ($list as $perm) $pm->execute([$r, $perm]);

    $po = $p->prepare('INSERT INTO policies(title,category,body) VALUES(?,?,?)');
    foreach ([
      ['Acceptable Use Policy','General','Company systems are for business use. Do not install unapproved software, share accounts, or access data you are not authorised to see. All activity may be monitored and logged.'],
      ['Password & Authentication Policy','Access Control','Passwords must be at least 8 characters with upper-case, lower-case, a digit and a symbol. Never reuse or share passwords. Multi-factor authentication is required for remote and privileged access.'],
      ['Access Control Policy','Access Control','Access is granted by role using the principle of least privilege. Access requests need manager approval, are reviewed quarterly, and are revoked immediately when a person leaves or changes role.'],
      ['Incident Response Policy','Operations','Report any suspected security incident (phishing, lost device, malware) to the security team immediately. Do not attempt to investigate or delete evidence yourself.'],
    ] as $x) $po->execute($x);

    $q = $p->prepare('INSERT INTO questions(q,opts,correct,explain) VALUES(?,?,?,?)');
    foreach ([
      ['Which password is the strongest?',['password123','Riya@2024','T7#kq!Lm9$Vz','qwertyuiop'],2,'Long, random and mixed-character passwords resist guessing and cracking.'],
      ['An email from "IT" asks you to click a link and verify your password. What do you do?',['Click and log in','Reply with your password','Forward it to colleagues','Report it as phishing'],3,'Legitimate IT never asks for passwords by email. Report it.'],
      ['You find a USB drive in the car park. Best action?',['Plug it in to find the owner','Take it home','Hand it to the IT/security team','Throw it away'],2,'Unknown USB devices can carry malware; let security handle them.'],
      ['"Least privilege" means users get...',['Admin rights by default','Only the access needed for their job','Access to everything read-only','No access at all'],1,'Minimum access needed reduces the damage from mistakes or compromised accounts.'],
      ['MFA combines two or more of...',['Something you know / have / are','Two passwords','Two usernames','Password and security question'],0,'Different factor types make stolen passwords alone useless.'],
      ['On public Wi-Fi you should...',['Do banking freely','Use a VPN and avoid sensitive logins','Disable your firewall','Share files openly'],1,'Public networks can be monitored; a VPN encrypts your traffic.'],
      ['An employee resigns. When should their access be revoked?',['After 30 days','At next audit','Immediately on exit','Never'],2,'Delayed de-provisioning is a common insider-threat gap.'],
      ['You suspect your laptop has malware. First step?',['Ignore it','Report to security immediately','Format it yourself','Keep working'],1,'Quick reporting limits spread and preserves evidence.'],
    ] as $x) $q->execute([$x[0], json_encode($x[1]), $x[2], $x[3]]);
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function flash($type, $msg) { $_SESSION['flash'] = [$type, $msg]; }
function csrf_field() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_check() {
    if (empty($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
        http_response_code(400); exit('Invalid CSRF token.');
    }
}
function log_action($action, $detail = '') {
    db()->prepare('INSERT INTO audit(user_id,action,detail,ip) VALUES(?,?,?,?)')
        ->execute([$_SESSION['user']['id'] ?? null, $action, $detail, $_SERVER['REMOTE_ADDR'] ?? '']);
}
function require_login() {
    if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
    $s = db()->prepare('SELECT id,name,email,role FROM users WHERE id=?');
    $s->execute([$_SESSION['user']['id']]);
    $u = $s->fetch();
    if (!$u) { session_destroy(); header('Location: login.php'); exit; }
    $_SESSION['user'] = $u; // always use fresh role from DB
}
function can($perm) {
    static $c = null;
    if (empty($_SESSION['user'])) return false;
    if ($c === null) {
        $s = db()->prepare('SELECT permission FROM perms WHERE role=?');
        $s->execute([$_SESSION['user']['role']]);
        $c = $s->fetchAll(PDO::FETCH_COLUMN);
    }
    return in_array($perm, $c, true);
}
function require_perm($perm) {
    require_login();
    if (!can($perm)) {
        log_action('access_denied', $perm . ' @ ' . basename($_SERVER['SCRIPT_NAME']));
        http_response_code(403);
        $title = 'Access denied'; include __DIR__ . '/header.php';
        echo '<div class="card"><h2>403 – Access denied</h2><p>Your role does not have the <b>' . e($perm) . '</b> permission.</p></div>';
        include __DIR__ . '/footer.php'; exit;
    }
}
function strong_password($p) {
    return strlen($p) >= 8 && preg_match('/[A-Z]/', $p) && preg_match('/[a-z]/', $p)
        && preg_match('/\d/', $p) && preg_match('/[^A-Za-z0-9]/', $p);
}
