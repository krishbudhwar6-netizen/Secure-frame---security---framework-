<?php $user = $_SESSION['user'] ?? null; ?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title ?? 'SecureFrame') ?> · SecureFrame</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="top"><a class="brand" href="dashboard.php">🛡️ SecureFrame</a>
<?php if ($user): ?><nav>
<a href="dashboard.php">Dashboard</a>
<?php if (can('view_policies')): ?><a href="policies.php">Policies</a><?php endif; ?>
<?php if (can('take_quiz')): ?><a href="awareness.php">Awareness</a><?php endif; ?>
<?php if (can('manage_users')): ?><a href="users.php">Users</a><?php endif; ?>
<?php if (can('manage_roles')): ?><a href="roles.php">Roles</a><?php endif; ?>
<?php if (can('view_audit')): ?><a href="audit.php">Audit log</a><?php endif; ?>
<form method="post" action="logout.php" class="inline"><?= csrf_field() ?><button class="link"><?= e($user['name']) ?> · Logout</button></form>
</nav><?php endif; ?></header><main>
<?php if (!empty($_SESSION['flash'])): [$t, $m] = $_SESSION['flash']; unset($_SESSION['flash']); ?>
<div class="flash <?= e($t) ?>"><?= e($m) ?></div><?php endif; ?>
