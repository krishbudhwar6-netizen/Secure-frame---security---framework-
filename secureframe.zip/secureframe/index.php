<?php header('Location: ' . (empty($_COOKIE[session_name()]) ? 'login.php' : 'dashboard.php'));
