<?php require 'includes/bootstrap.php';
if (!empty($_SESSION['user'])) { header('Location: dashboard.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $s = db()->prepare('SELECT * FROM users WHERE email=?');
    $s->execute([strtolower(trim($_POST['email'] ?? ''))]);
    $u = $s->fetch();
    if ($u && $u['locked_until'] > time()) {
        $err = 'Account locked. Try again in ' . ceil(($u['locked_until'] - time()) / 60) . ' minute(s).';
    } elseif ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
        db()->prepare('UPDATE users SET failed=0, locked_until=0 WHERE id=?')->execute([$u['id']]);
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $u['id'], 'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role']];
        log_action('login', $u['email']);
        header('Location: dashboard.php'); exit;
    } else {
        if ($u) {
            $f = $u['failed'] + 1;
            $lock = $f >= 5 ? time() + 300 : 0;
            db()->prepare('UPDATE users SET failed=?, locked_until=? WHERE id=?')->execute([$lock ? 0 : $f, $lock, $u['id']]);
        }
        db()->prepare('INSERT INTO audit(user_id,action,detail,ip) VALUES(?,?,?,?)')
            ->execute([$u['id'] ?? null, 'login_failed', $_POST['email'] ?? '', $_SERVER['REMOTE_ADDR'] ?? '']);
        $err = 'Invalid email or password.';
    }
}
$title = 'Login'; include 'includes/header.php'; ?>
<div class="card narrow"><h2>Sign in</h2>
<?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button>Login</button></form>
<p class="muted">New here? <a href="register.php">Create an account</a></p>
<p class="muted small">Demo: admin@demo.com / Admin@123 · manager@demo.com / Manager@123 · employee@demo.com / Employee@123</p></div>
<?php include 'includes/footer.php'; ?>
