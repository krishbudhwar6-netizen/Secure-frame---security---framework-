<?php require 'includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { csrf_check(); if (!empty($_SESSION['user'])) log_action('logout'); }
$_SESSION = []; session_destroy(); header('Location: login.php');
