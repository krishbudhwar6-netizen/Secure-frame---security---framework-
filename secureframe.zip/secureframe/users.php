<?php require 'includes/bootstrap.php'; require_perm('manage_users');
$me = $_SESSION['user']['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $a = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    if ($a === 'role' && in_array($_POST['role'] ?? '', ROLES, true) && $id !== $me) {
        db()->prepare('UPDATE users SET role=? WHERE id=?')->execute([$_POST['role'], $id]);
        log_action('role_change', "user #$id -> " . $_POST['role']); flash('ok', 'Role updated.');
    } elseif ($a === 'unlock') {
        db()->prepare('UPDATE users SET failed=0, locked_until=0 WHERE id=?')->execute([$id]);
        log_action('unlock', "user #$id"); flash('ok', 'Account unlocked.');
    } elseif ($a === 'delete' && $id !== $me) {
        db()->prepare('DELETE FROM acks WHERE user_id=?')->execute([$id]);
        db()->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
        log_action('user_delete', "user #$id"); flash('ok', 'User deleted.');
    } elseif ($a === 'add') {
        $n = trim($_POST['name'] ?? ''); $em = strtolower(trim($_POST['email'] ?? '')); $pw = $_POST['password'] ?? ''; $r = $_POST['role'] ?? '';
        if ($n && filter_var($em, FILTER_VALIDATE_EMAIL) && strong_password($pw) && in_array($r, ROLES, true)) {
            try { db()->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)')->execute([$n, $em, password_hash($pw, PASSWORD_DEFAULT), $r]);
                  log_action('user_add', $em); flash('ok', 'User created.'); }
            catch (PDOException $x) { flash('err', 'Email already exists.'); }
        } else flash('err', 'Check name, email, role and strong password.');
    } else flash('err', 'Action not allowed (you cannot change or delete yourself).');
    header('Location: users.php'); exit;
}
$users = db()->query('SELECT * FROM users ORDER BY id')->fetchAll();
$title = 'Users'; include 'includes/header.php'; ?>
<h1>User management</h1>
<div class="card"><div class="scroll"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr>
<?php foreach ($users as $u): $locked = $u['locked_until'] > time(); ?>
<tr><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="role"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
<select name="role" <?= $u['id'] == $me ? 'disabled' : '' ?>><?php foreach (ROLES as $r): ?><option <?= $u['role'] === $r ? 'selected' : '' ?>><?= e($r) ?></option><?php endforeach; ?></select>
<?php if ($u['id'] != $me): ?><button class="small">Save</button><?php endif; ?></form></td>
<td><?= $locked ? '<span class="badge bad">Locked</span>' : '<span class="badge ok">Active</span>' ?></td>
<td class="actions"><?php if ($locked): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="unlock"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="small">Unlock</button></form><?php endif; ?>
<?php if ($u['id'] != $me): ?><form method="post" class="inline" onsubmit="return confirm('Delete user?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="small danger">Delete</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></table></div></div>
<div class="card"><h3>Add user</h3><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<label>Role<select name="role"><?php foreach (ROLES as $r): ?><option <?= $r === 'employee' ? 'selected' : '' ?>><?= e($r) ?></option><?php endforeach; ?></select></label>
<button>Create user</button></form></div>
<?php include 'includes/footer.php'; ?>
