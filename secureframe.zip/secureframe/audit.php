<?php require 'includes/bootstrap.php'; require_perm('view_audit');
$rows = db()->query('SELECT a.*, u.email FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200')->fetchAll();
$title = 'Audit log'; include 'includes/header.php'; ?>
<h1>Audit log</h1><p class="muted">Last 200 security-relevant events.</p>
<div class="card"><div class="scroll"><table><tr><th>Time (UTC)</th><th>User</th><th>Event</th><th>Detail</th><th>IP</th></tr>
<?php foreach ($rows as $r): $bad = in_array($r['action'], ['access_denied', 'login_failed']); ?>
<tr class="<?= $bad ? 'warn' : '' ?>"><td><?= e($r['created_at']) ?></td><td><?= e($r['email'] ?? '—') ?></td><td><?= e($r['action']) ?></td><td><?= e($r['detail']) ?></td><td><?= e($r['ip']) ?></td></tr>
<?php endforeach; ?></table></div></div>
<?php include 'includes/footer.php'; ?>
