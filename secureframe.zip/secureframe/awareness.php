<?php require 'includes/bootstrap.php'; require_perm('take_quiz');
$uid = $_SESSION['user']['id'];
$qs = db()->query('SELECT * FROM questions ORDER BY id')->fetchAll();
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $score = 0; $review = [];
    foreach ($qs as $q) {
        $ans = isset($_POST['q'][$q['id']]) ? (int)$_POST['q'][$q['id']] : -1;
        $ok = $ans === (int)$q['correct']; if ($ok) $score++;
        $review[] = ['q' => $q, 'ans' => $ans, 'ok' => $ok];
    }
    db()->prepare('INSERT INTO quiz_results(user_id,score,total) VALUES(?,?,?)')->execute([$uid, $score, count($qs)]);
    log_action('quiz', "$score/" . count($qs));
    $result = ['score' => $score, 'review' => $review];
}
$s = db()->prepare('SELECT * FROM quiz_results WHERE user_id=? ORDER BY id DESC LIMIT 5'); $s->execute([$uid]); $hist = $s->fetchAll();
$title = 'Awareness'; include 'includes/header.php'; ?>
<h1>Security awareness</h1>
<div class="grid">
<div class="card"><h3>🎣 Spot phishing</h3><p>Check the sender address, hover over links, beware of urgency and requests for credentials.</p></div>
<div class="card"><h3>🔑 Protect passwords</h3><p>Use a password manager, unique passwords per site, and enable MFA everywhere.</p></div>
<div class="card"><h3>💾 Handle data safely</h3><p>Lock your screen, never plug in unknown USB drives, and share data only with authorised people.</p></div>
</div>
<?php if ($result): ?>
<div class="card"><h2>Your score: <?= (int)$result['score'] ?> / <?= count($qs) ?></h2>
<?php foreach ($result['review'] as $i => $r): $opts = json_decode($r['q']['opts'], true); ?>
<div class="review <?= $r['ok'] ? 'good' : 'badq' ?>"><b><?= $i + 1 ?>. <?= e($r['q']['q']) ?></b><br>
<?= $r['ok'] ? '✔ Correct' : '✖ Your answer: ' . e($r['ans'] >= 0 ? $opts[$r['ans']] : 'none') ?> — Correct: <?= e($opts[$r['q']['correct']]) ?><br>
<span class="muted small"><?= e($r['q']['explain']) ?></span></div>
<?php endforeach; ?><a href="awareness.php">Retake quiz</a></div>
<?php else: ?>
<form method="post" class="card"><?= csrf_field() ?><h2>Awareness quiz</h2>
<?php foreach ($qs as $i => $q): $opts = json_decode($q['opts'], true); ?>
<fieldset><legend><?= $i + 1 ?>. <?= e($q['q']) ?></legend>
<?php foreach ($opts as $k => $o): ?><label class="opt"><input type="radio" name="q[<?= (int)$q['id'] ?>]" value="<?= $k ?>" required> <?= e($o) ?></label><?php endforeach; ?></fieldset>
<?php endforeach; ?><button>Submit answers</button></form>
<?php endif; ?>
<?php if ($hist): ?><div class="card"><h3>Your recent attempts</h3><table><tr><th>Date</th><th>Score</th></tr>
<?php foreach ($hist as $h): ?><tr><td><?= e($h['taken_at']) ?></td><td><?= (int)$h['score'] ?> / <?= (int)$h['total'] ?></td></tr><?php endforeach; ?></table></div><?php endif; ?>
<?php include 'includes/footer.php'; ?>
