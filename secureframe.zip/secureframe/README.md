# SecureFrame – Security Policy, Access Control & Awareness Framework

A working PHP website (no MySQL setup needed – uses a SQLite file that is auto-created on first run).

## Run it
**Option A – XAMPP:** copy the `secureframe` folder into `C:\xampp\htdocs\`, start Apache, open http://localhost/secureframe/
**Option B – PHP built-in server:** `cd secureframe` then `php -S localhost:8000` and open http://localhost:8000
(Requires PHP 7.4+ with the pdo_sqlite extension – enabled by default in XAMPP. The `data/` folder must be writable.)

## Demo logins
| Role | Email | Password |
|---|---|---|
| Admin | admin@demo.com | Admin@123 |
| Manager | manager@demo.com | Manager@123 |
| Employee | employee@demo.com | Employee@123 |

To reset everything, delete `data/app.sqlite`.

## The three pillars
1. **Security Policy** – `policies.php`: policy library, users digitally acknowledge each policy, admins add/delete policies.
2. **Access Control** – RBAC with a permission matrix (`roles.php`), user management (`users.php`), least privilege, 403 page, account lockout (5 failed logins = 5 min), audit log (`audit.php`).
3. **Awareness** – `awareness.php`: security tips, 8-question quiz with explanations, score history.

## Security features implemented
Password hashing (bcrypt via password_hash), strong-password rule, prepared statements (SQL injection), output escaping (XSS), CSRF tokens on all forms, session ID regeneration, HttpOnly/SameSite cookies, CSP and clickjacking headers, role re-checked from DB on every request, audit logging of logins, denied access and admin actions.

## Structure
`index.php, login.php, register.php, logout.php, dashboard.php, policies.php, users.php, roles.php, awareness.php, audit.php` · `includes/` (bootstrap, header, footer) · `assets/style.css` · `data/` (SQLite DB)
