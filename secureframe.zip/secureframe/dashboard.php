<?php require 'includes/bootstrap.php'; require_login();
$uid = $_SESSION['user']['id']; $pdo = db();
$totalPol = $pdo->query('SELECT COUNT(*) FROM policies')->fetchColumn();
$s = $pdo->prepare('SELECT COUNT(*) FROM acks WHERE user_id=?'); $s->execute([$uid]); $acked = $s->fetchColumn();
$s = $pdo->prepare('SELECT score,total,taken_at FROM quiz_results WHERE user_id=? ORDER BY id DESC LIMIT 1'); $s->execute([$uid]); $last = $s->fetch();
$title = 'Dashboard'; include 'includes/header.php'; ?>
<h1>Welcome, <?= e($_SESSION['user']['name']) ?></h1>
<p class="muted">Role: <span class="badge"><?= e($_SESSION['user']['role']) ?></span></p>
<div class="grid">
<div class="card stat"><h3>Policies acknowledged</h3><div class="big"><?= (int)$acked ?> / <?= (int)$totalPol ?></div>
<?php if (can('view_policies')): ?><a href="policies.php">Review policies →</a><?php endif; ?></div>
<div class="card stat"><h3>Latest awareness score</h3><div class="big"><?= $last ? e($last['score'] . ' / ' . $last['total']) : '—' ?></div>
<?php if (can('take_quiz')): ?><a href="awareness.php">Take the quiz →</a><?php endif; ?></div>
<?php if (can('manage_users')): ?><div class="card stat"><h3>Registered users</h3><div class="big"><?= (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() ?></div><a href="users.php">Manage users →</a></div><?php endif; ?>
<?php if (can('view_audit')): ?><div class="card stat"><h3>Denied / failed events</h3><div class="big"><?= (int)$pdo->query("SELECT COUNT(*) FROM audit WHERE action IN ('access_denied','login_failed')")->fetchColumn() ?></div><a href="audit.php">Open audit log →</a></div><?php endif; ?>
</div>
<div class="card"><h3>Your permissions</h3><ul class="perms">
<?php foreach (PERMS as $k => $label): ?><li class="<?= can($k) ? 'yes' : 'no' ?>"><?= can($k) ? '✔' : '✖' ?> <?= e($label) ?></li><?php endforeach; ?></ul></div>
<?php include 'includes/footer.php'; ?>
