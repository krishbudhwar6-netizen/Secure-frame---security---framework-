<?php require 'includes/bootstrap.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $pw = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Enter a valid name and email.';
    elseif (!strong_password($pw)) $err = 'Password needs 8+ chars with upper, lower, digit and symbol.';
    else {
        try {
            db()->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)')
                ->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT), 'employee']);
            db()->prepare('INSERT INTO audit(action,detail,ip) VALUES(?,?,?)')->execute(['register', $email, $_SERVER['REMOTE_ADDR'] ?? '']);
            flash('ok', 'Account created. Please log in.'); header('Location: login.php'); exit;
        } catch (PDOException $ex) { $err = 'That email is already registered.'; }
    }
}
$title = 'Register'; include 'includes/header.php'; ?>
<div class="card narrow"><h2>Create account</h2>
<?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Full name<input name="name" required></label>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<p class="muted small">Minimum 8 characters with upper-case, lower-case, a digit and a symbol. New accounts get the <b>employee</b> role.</p>
<button>Register</button></form>
<p class="muted"><a href="login.php">Back to login</a></p></div>
<?php include 'includes/footer.php'; ?>
