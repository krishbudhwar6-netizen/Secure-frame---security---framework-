<?php require 'includes/bootstrap.php'; require_perm('view_policies');
$uid = $_SESSION['user']['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $a = $_POST['action'] ?? '';
    if ($a === 'ack') {
        $id = (int)$_POST['id'];
        db()->prepare('INSERT OR IGNORE INTO acks(user_id,policy_id) VALUES(?,?)')->execute([$uid, $id]);
        log_action('policy_ack', "policy #$id"); flash('ok', 'Policy acknowledged.');
    } elseif ($a === 'add' && can('manage_policies')) {
        $t = trim($_POST['title'] ?? ''); $c = trim($_POST['category'] ?? ''); $b = trim($_POST['body'] ?? '');
        if ($t && $b) {
            db()->prepare('INSERT INTO policies(title,category,body) VALUES(?,?,?)')->execute([$t, $c ?: 'General', $b]);
            log_action('policy_add', $t); flash('ok', 'Policy added.');
        } else flash('err', 'Title and text are required.');
    } elseif ($a === 'delete' && can('manage_policies')) {
        $id = (int)$_POST['id'];
        db()->prepare('DELETE FROM acks WHERE policy_id=?')->execute([$id]);
        db()->prepare('DELETE FROM policies WHERE id=?')->execute([$id]);
        log_action('policy_delete', "policy #$id"); flash('ok', 'Policy deleted.');
    } else { log_action('access_denied', "policy action $a"); flash('err', 'Not permitted.'); }
    header('Location: policies.php'); exit;
}
$s = db()->prepare('SELECT p.*, (SELECT COUNT(*) FROM acks a WHERE a.policy_id=p.id AND a.user_id=?) mine,
    (SELECT COUNT(*) FROM acks a WHERE a.policy_id=p.id) total FROM policies p ORDER BY p.id');
$s->execute([$uid]); $rows = $s->fetchAll();
$users = db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
$title = 'Policies'; include 'includes/header.php'; ?>
<h1>Security policies</h1>
<?php foreach ($rows as $p): ?>
<div class="card"><div class="row"><h3><?= e($p['title']) ?></h3><span class="badge"><?= e($p['category']) ?></span></div>
<p><?= nl2br(e($p['body'])) ?></p>
<div class="row"><span class="muted small">Acknowledged by <?= (int)$p['total'] ?> of <?= (int)$users ?> users</span>
<span class="actions">
<?php if ($p['mine']): ?><span class="badge ok">✔ You acknowledged</span>
<?php else: ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="ack"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button>I have read &amp; agree</button></form><?php endif; ?>
<?php if (can('manage_policies')): ?><form method="post" class="inline" onsubmit="return confirm('Delete policy?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="danger">Delete</button></form><?php endif; ?>
</span></div></div>
<?php endforeach; ?>
<?php if (can('manage_policies')): ?>
<div class="card"><h3>Add a policy</h3><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<label>Title<input name="title" required></label><label>Category<input name="category" placeholder="General"></label>
<label>Policy text<textarea name="body" rows="4" required></textarea></label><button>Add policy</button></form></div>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
